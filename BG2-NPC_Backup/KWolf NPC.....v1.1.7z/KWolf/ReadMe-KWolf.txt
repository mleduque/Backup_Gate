May 2, 2001
My email: inintrag@yahoo.com

This is a new NPC as well as a store. He will join your party if you are a certain level or higher. He also has his own store. You cannot access his store items if he is in your party. There is a way to incorporate that function but I removed it as it doesn't seem realistic to be able to access his store while out in the middle of nowhere. His original spot is upstairs in the Five Flagons Inn(ar0511). If you do use him in your party and then drop him, he will go the the Five Flagons. When using his store, you will notice that most of the items are not identified. That is because they are from another game called Fallout. If you know what they are, then purchase them, if not, have fun discovering what they are!
  
Special Thanks to:
http://www.teambg.com/
THE source for BG2 programs
http://www.mud-master.com/shadowkeeper/index.html
The ULTIMATE Saved Game Editor for BG2(it's also the only one, I think)
http://metalfan490.tripod.com/bg2items/index.html
This guy knows his sh*t!  Couldn't have done it without him!
http://waterdeep.homeip.net/potenciusnet/
Potencius' site, also knows his sh*t!
http://infexp.sourceforge.net/
The Infinity Explorer
And of course:
Todd (aka TL or Gustov Montessi) Infinity Engine Editor Pro(and Add-On Patcher)
http://www8.50megs.com/gustovm/InfinityEngineGames.html
http://www.geocities.com/gustovmontessi/InfinityEngineGames.html

The ONLY program that lets you forge items to rival those made by the gods.

DISCLAIMER:

Use these files at your own risk.  If by some weird, fantastical quirk of fate they damage your computer, I cannot be held responsible.  Nor can the website you downloaded them from be held responsible as well.  With that out of the way, if you do have problems, let me know.  I'll try and help.
My email:  inintrag@yahoo.com


VERSION HISTORY

VERSION 1
- Initial release

VERSION 1.1
- Added Italian translation by Ilot
- Added VERSION-flag
- Updated WeiDU v210

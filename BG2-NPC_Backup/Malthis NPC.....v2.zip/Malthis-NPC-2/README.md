# Malthis-NPC v2

A mod for Baldur's gate 2

Available language : German & French

I am by no mean the owner of this mod, this is just a temporary solution to host the mod.

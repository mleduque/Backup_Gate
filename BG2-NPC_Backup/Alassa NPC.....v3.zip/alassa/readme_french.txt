AVERTISSEMENT : Ceci est un One-Day NPC(tm). Cela signifie que ce mod a �t� �crit et r�alis� en une journ�e. 
Il y a probablement quelques bugs, et l'audio n'est peut-�tre pas parfaitement �quilibr�. Car comme son nom l'indique, tout le d�veloppement a �t� fait en un jour.

			  MOD PNJ Alassa pour Baldur's Gate 2
			             VERSION 3
                	           ONE-DAY NPC(tm)
			    Un projet du groupe Pocket Plane
			       http://www.pocketplane.net

- Une voleuse d'alignement mauvais
- Quelque interjections, un �pilogue, etc...
- ... et des bavardages
- Un nouveau soundset (aussi cr�� en un jour, f�licitations � Sorschana !)
- Quelque chose qui aurait pu �tre une qu�te si je n'�tais pas aussi paresseux
- Un readme assembl� � la h�te
- R�alis� en un jour, plus ou moins, moins les moments o� j'en ai eu assez et suis all� faire autre chose.

Installation :
- Copiez le contenu de l'archive dans votre dossier d'installation BG2 et ex�cutez setup-alassa.exe. Le mod peut �tre d�sinstall� en ex�cutant setup-alassa.exe � nouveau.

Information :
- Vous pourrez trouver Alassa dans les bas-quartiers, pr�s de la maison de Jansen. Elle devrait vous aborder.

El�ments qui n'ont pas �t� cr��s en un jour :
- Portrait. Je m'�tais amus� dessus auparavant.
- Distribution. J'ai tout assembl� le lendemain matin. Aucun contenu n'a �t� ajout�, cela dit.

Remerciements :
- SimDing0 - Ecriture, encodage
- Sorschana - Doublage
- JCompton - Toujours pr�t � aider

Age l�gal:
- 16 ans et plus.


Version-History:

Version 1
- First public release

Version 2
- Traified the mod
- Added German translation by Thioderik
- Added VERSION-flag
- Updated to WeiDU v210

Version 3
- Added French translation by Shaywen and Zooloo, of the d'Oghmatiques
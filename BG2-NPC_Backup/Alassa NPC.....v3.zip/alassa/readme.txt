WARNING: This is a One-Day NPC(tm). That means it was written and released in a
day. That means it's probably got some bugs. The audio's probably not perfectly
balanced. As the name implies, all the work was done in a day.

			  Alassa NPC MOD For Baldur�s Gate 2
			             VERSION 3
                	           ONE-DAY NPC(tm)
			     A Pocket Plane Group Project
			   http://www.pocketplane.net

- An evil female thief
- A few interjects, epilogue, etc.
- ...and some banter
- A new soundset (actually also done within a day; cheers Sorschana!)
- Something that was could have been a quest if I wasn't so lazy
- A hastily assembled readme
- A day in the making, give or take the bits when I got bored and went to do something else

Installation:
- Copy the contents of this archive to your BG2 folder and run setup-alassa.exe. The mod can be uninstalled by running it again.

Information:
- Alassa can be found in the slums, near the Jansen home. She should approach you.

What wasn't done within a day:
- Portrait. I had a bit of fun doing this in advance.
- Distribution. I packaged everything the following morning. No content was added, mind.

Credits:
- SimDing0 - Writing, coding
- Sorschana - Voicing
- JCompton - Always helpful

Legal:
- Only when you're 16.


Version-History:

Version 1
- First public release

Version 2
- Traified the mod
- Added German translation by Thioderik
- Added VERSION-flag
- Updated to WeiDU v210

Version 3
- Added French translation by Shaywen and Zooloo, of the d'Oghmatiques

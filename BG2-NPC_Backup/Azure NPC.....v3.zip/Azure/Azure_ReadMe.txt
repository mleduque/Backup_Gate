Azure NPC BETA v3(04.09.05)
Author: Victor Georgiev 
Balduran@abv.bg 


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
COMPONENTS:
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
1.Nature's Ally Druid Kit
2. Azure NPC

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ABOUT:
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Azure is a Romancable NPC. She is a Nature's Ally druid and has a guardian wolf, which follows her wherever she goes.

"Azure grew up in a very poor family, she had to wander the streets, begging. At age six she witnessed her father beating her mother to death. When she was 13, she was sold by her ever drunken dad to a local broddel. At age 16 she supposedly died, after drinking a potion which was to terminate her pregnancy.
Instead of dying, she was awarded a second life, as acompensation for her sufferings and woke up in Tethir, with the wolf at her side. She was found three days later, be a group of elves, who brought her to a druid village. Two years later the village was pillaged by drow raider, who captured one of the druids and tortured him until he told them where the village was located. Azure survived the raid thanks to Sharo, who put a spell on her, so that she would not be noticed by the drow."

These are the basics of her story, which are part of a novel I am writing, although I changed the gender and name of both main character and guardian, so that it fits a romance for a male protagonist. For those who care, the working title of the novel is "The Branded Man". It should give you some ideas how the story of the romance will develop.

I've been considering also some background alternatives. One of them involves Azure being a "working girl", who received a second chance for (litarally)new life as conpensation for her sufferings.

About Azure:
~~~~~~~~~~
She can be found in the Druid Grove area, but only if you are currently in Chapters 2 or 3 (from BETA v3 on). That means that if you left for Brynnlaw before taking her into the party, she'll be gone.
Azure so far has only a few lines within the game, although I plan to have the romance finished by the end of September. The only interjection she gets so far is from Cernd upon joining. When you meet her, she is separated from her guardian, Sharo, and asks for your help to find him. There's a timer, which counts the days until you find him, and if you delay too much she will threaten to leave, and if you haven't found Sharo by the next day, then she will leave forever. Azure also leaves forever if she is kicked out of the party, though I plan to change that in the final version of the mod.
Azure has an irremovable Wolf Amulet, which is the link between her and Sharo. It currently protects her from some of the nastiest game effects that could ruin a romance, such as Petrification and Imprisonment.


About Sharo:
~~~~~~~~~~
Sharo is a wolf. He is the guardian of Azure and he is far from being an ordinary wolf. At the moment you cannot really control him, although he will jump areas with you as long as Azure is in the party. Currently he will stay with the protagonist and become his/her guardian if you manage to get Azure killed. Sharo will search for traps in dungeons, but don't expect him to disarm them for you. He will also attack anyone who attacks Azure or himself. He will attack anyone who attacks the protagonist if Azure is dead. Right now Sharo has two attack patterns:
1) He will rush and attack an enemy who attacks him or Azure (or Player1 if Azure is dead) in melee combat.
2) If Azure (or Protagonist if Azure is dead) is attacked with ranged attack or attacker is more than 8 feet away from Azure, then he will become invisible and try to backstab the attacker. I tested it several times and it worked every time, except for that case when the party was attacked by a spirit troll. Sharo just stood there doing nothing.
Sharo will also heal Azure (or Protagonist if Azure is dead) if he sees her and she is seriously wounded. He will also heal himself if is wounded critically.
Sharo leaves the group if Azure is kecked out.
NOTE ON JUMPING AREAS:
I originally extended the bottom of dplayer3.bcs, just like it was done in the Every Mod&Dog mod. However, using this script means that if you want Sharo to jump from one area to another, you should keep the AI on, or turn it on for a sec every time you enter new area. This wasn't satisfying, so I instead used the EXTEND_BOTTOM_REGXP command of WeiDu to write the jump into each and every area script file.
Something Odd: Sharo doesn't want to attack creature's summoned by the party if they become red(enemy). If anyone has idea how to change this without turning Sharo against the party, feel free to share it with me.

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
About the Nature's Ally druid kit:
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Nature's Allies have devoted their lives to protecting nature from the abuse of all human and non-human intervention.

Advantages:
- Gains the ability to summon wyverns thatt assist him/her for 5 turns as follows:
1 level - can summon Baby Wyverns
10 level - can summon grown Wyverns
14 level - can summon Great Wyverns
21 level - can summon Spirit Wyvern

- Gains the ability "Nature's Allies". Wheen cast, all animals in caster sight are charmed unless they make a successful save throw. This ability improves with levelling.
- Can choose a potentionally very powerfull modification of the Sleep spell as a High-level ability. All creatures in the area of effect must save with -7 penalty or fall asleep.
- Can dual to fighter, cleric and ranger.

Disadvantages:
- Cannot wear armour greater than leather..
- Cannot shapechange


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
HELP NEEDED
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

I'm looking for a voice artist willing to donate her voice to Azure. If you feel up to it, contact me.
Also, if anyone has any suggestions about the romance development, and especially about interparty banters, then PLEEEAASE send me a mail or leave a message on the mod's forum.
Any ideas about tactical fights related to Azure romance, or even scripts for a Nature's Ally druid would be welcome.


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Version History
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BETA v1: Initial release
BETA v2: 
-The timer for finding Sharo was fixed.
-Fixed bug causing Sharo to be moved next to Azure all the time.
-Improved the override script of Sharo
-Removed a useless script
-Added a few lovetalk dialogs
BETA v3:
-Improved the override script of Sharo
-Improved another script of Sharo
-Added more lovetalk dialogs 

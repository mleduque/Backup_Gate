WARNING: This is a One-Day NPC(tm). That means it was written and 
released in a day. (Or a day, as defined by The Speed of Bons). That 
means it's probably got some bugs. What's more, this is an 
excerpt/spoiler for the Surayah NPC project. That means about 
half of the banters and the quest reference a larger piece of work.

             Hessa NPC MOD For Baldur�s Gate 2
			 VERSION 1.1
                     ONE-DAY NPC***(tm)
	          A Forgotten Wars Project
	        http://www.forgottenwars.net

When Jason Compton came up with the One-Day NPC concept, I immediately 
thought it would be fun to give it a try, and I needed the experience. 
The catch was, even a day is a large time committment when you have a 
modding project that's calling for a lot of work. Hessa NPC is my 
compromise: part new joinable character, part Surayah mod content.

Hessa yr Nu'man will approach the party at the City Gates of Athkatla 
after Anomen has killed Surayah in the revenge-against-Saerk path of 
his storyline. She will present herself as a source of information 
about the current location of Yusef Farrahd, which she will offer up 
at a price.

This mod includes:

- One neutral evil, half-elf thief, level 12, 13 or 15 depending on 
the party's experience at the first encounter.

- One small NPC-related quest

- One small, new quest-related area (Because this adds a new area to 
the worldmap, you MUST BEGIN A NEW GAME to play this mod properly.)

- One new soundset of dubious entertainment value

- 12 banters and 20-something interjections


INSTALLING HESSA NPC

Throne Of Bhaal is Required. Though Hessa has only SoA content 
for now, features of this mod require the presence of ToB-specific 
files for it to work.

You should obtain and install the latest TOB patch from 
www.interplay.com or www.bioware.com BEFORE installing this mod. 
Install this patch before installing any mods. Otherwise, something 
will likely go very wrong during your gameplay experience, and you 
will become very sad.

1. Extract the contents of HessaNPC.rar into the BGII - SofA folder 
on your computer.

2. Double-click Setup-HessaNPC.exe. A console window (DOS window) 
opens up and asks whether or not you wish to install Hessa. Answer Yes.

3. You'll se a list of files being copied, and scripts and dialogue 
being compiled. This process may take a minute or two on a slower system.

4. After the text window tells you to press enter to exit, there 
is one final stage--decompressing the compressed audio and tileset 
included with Hessa to standard WAV and TIS format. The window will 
fill with text: THIS IS NORMAL. This process may take a few minutes on 
a slower system.

5. Start a new game and enjoy!

If anything goes wrong with the process, or you later wish to 
uninstall Hessa, run the Setup-Hessa.exe program once more and select 
the U option.

MORE INFO

You can keep up to date on any further developments with Hessa 
at the One-Day NPCs(tm) and Surayah NPC forums at www.forgottenwars.net. 
Questions to me can be directed to llamababe@carolina,rr.com

TECHNICAL

Hessa should be highly compatible with virtually any other mod out there.

Hessa was created using these fine tools:

WeiDU
Near Infinity
IETME
DLTCEP
Shadow Keeper
BAM Workshop
TISpack


FREQUENTLY ASKED QUESTIONS

Q: Did you actually finish this in one day?

A: Err, honestly? No. This mod constitutes about 40 hours of 
work, so it's more like a One-Week NPC. About 24-hours of that was 
spent on materials and writing (vaguely justifying the One-Day stamp), 
while the rest was used for testing, debugging, and drinking juice.

Q: Do I have to have Anomen in my party to play with Hessa?

A: Yes and no. Since Hessa appears after Surayah is killed in the 
Anomen-plot related cutscene, you have to have him in the party 
sometime. After the confrontation with Saerk, you don't need to 
keep Anomen around. Hessa should speak and/or join your party 
whether Anomen is in the party or not.

Q: Ack! I talked to Hessa once, and now she's disappeared!

A: After the initial conversation with the party at the City Gates, 
Hessa moves to the second floor of The Five Flagons [1250,400] in the 
Bridge District. This is also where she goes if she is kicked out of 
the party.

Q: Do I have to start a new game to play this mod?

A: Yes. This mod adds a new area to the worldmap, which is formed at 
the start of a new game. If you try to play with Hessa in an existing 
game, the quest area will not appear, and you may experience other 
unpleasant side effects. 

Q: Hessa just told me she revealed the location of Surayah's grave 
on the worldmap, and nothing appears!

A: Nothing should. Events related to the gravesite area are part 
of the Surayah mod. What's included here is an unfinished glimpse into 
how Hessa fits into that larger plot.

HISTORY

2/22/04 - Version 1 released

2/23/04 - Version 1.1 released - Corrects two small bugs, including the 
missing End Dialogue in the Valygar banter. Also corrects the problem 
where audio doesn't uninstall.

CREDITS

Bonnie Rutledge		Writing, Coding, Voicing, Graphics, etc.
llamababe@carolina.rr.com

Portions of this ReadMe were stolen from Jason Compton's finely-tuned
ReadMe work.

Hessa employs Ogg Vorbis for audio encoding and decoding. More information,
including complete source code, can be found at http://www.xiph.org,
http://www.vorbis.com

Hessa uses the TISPack tool for tileset compression/decompression. 
Pick up your own handy copy at 
http://www.forgottenwars.net/?page=tools/tispack

Thanks to Jason Compton for troubleshooting help, and to JC and 
Ghreyfain for all their examples and tutorials, without which, this would 
have never gotten off the ground.

Hessa, Copyright � 2004 Bonnie Rutledge.

Hessa is not developed, supported, or endorsed by BioWare or 
Interplay/Black Isle.




LINKS

http://www.weidu.org:                 Home of WeiDU and Solaufein

http://www.forgottenwars.net:         Home of Kelsey, and other fine
                                      projects!

http://www.idi.ntnu.no/~joh/ni:       Home of Near Infinity

http://infexp.sourceforge.net:        Home of Infinity Explorer

http://www.teambg.net/~avenger/       Home of DLTCEP


*** Yeah, One-Day if you live on Pluto
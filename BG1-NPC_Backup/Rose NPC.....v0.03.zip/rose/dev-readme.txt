VARIABLES
k-rose-joined
 0: Rose never joined the party
 1: Rose is in party
 2: Rose joined and has been kicked
k-rose-exist
 0: Rose hasn't been created yet
 1: Rose has been created
k-rose-ftimer
 timer for friendship banters
k-rose-realftimer
 real time timer for friendship banters
k-rose-ftalk
 counter for friendship banters
k-rose-ltimer
 timer for friendship banters
k-rose-ltalk
 counter for friendship banters
ENDOFBG1
 0: BG1\TotSC part of the game;
 1: Killed Sarevok, but still on the BG1 part
 2: SoA
k-rose-romance
 0: Can't romance Rose
 1: Can romance
 2: Romancing
 3: Romance screwed
k-rose-oublekmistake
 1: banter allowed
 2: already had the banter about Oublek's mistake
k-rose-sunset
 1: already had the banter about the sunset
k-rose-friendship
 friendship counter
k-rose-pid1
 1: already had player initiated dialog number 1
k-rose-spider
 1: banter allowed
 2: already had the spider body dialog
k-rose-zombiefarm
 1: talked with Wenric
 2: already had banter about zombies (1)
 3: already had (or skipped) banter about zombies (2, at the inn)
k-rose-zftimer
 timer for the zombie talk 2
k-rose-silkemerc
 0: Mercenaries not spawned yet
 1: spawned
 2: fighting or killed
 3: pacific solution

---

FT1: Rose wants to adventure
FT2: charname's tastes about music
FT3: Rose's and charname's dreams
FT4: Rose's family

PID1: about why Rose started adventuring and Charname's past/requires friendship>1